WEB DE JOSE ANTONIO ARCENTALES CEDEÑO

Archivo principal: index.html

La web incluye:
- Barcelona y alrededores
- Instalaciones eléctricas
- Averías y reparaciones
- Iluminación
- Cuadros eléctricos
- Mantenimiento
- Galería de imágenes de referencia
- Botones de llamada directa
- Teléfono de servicio: 609 374 383
- Teléfono de oficina: 655 447 927

IMPORTANTE:
Las imágenes de la galería son imágenes de referencia alojadas externamente. Antes de publicar comercialmente la web, conviene sustituirlas por fotografías reales de los trabajos de Jose Antonio y añadir los datos legales/profesionales que correspondan.
